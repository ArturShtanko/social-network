
import React from "react";
import Post from "./post/post.js";

let postText = React.createRef();

function Posts(props){
    let addPost = () => {
         props.addPost(postText.current.value);
        }
    return(
        <div className="posts">

            <div className="posts-input-wrapper">
                <h2>My Posts</h2>
                <input ref={postText} placeholder="enter the post"></input>
                <button onClick={addPost}>Add Post</button>
               
            </div>

            <div className="posts-wrapper">
                {props.messages.map((e) => <Post message={e.message} likes={e.likes}></Post>)}
            </div>
            
        </div>
    )
}

export default Posts;