
import React from "react";
import "./profile.css"

import Posts from "./posts/posts";
import ProfileInfo from "./profile-info/profileInfo";

function Profile(props){
  return(
    <div className="profile">

      <ProfileInfo></ProfileInfo>

      <Posts messages={props.messageData} addPost={props.addPost}></Posts>

    </div>
  );
}

export default Profile;