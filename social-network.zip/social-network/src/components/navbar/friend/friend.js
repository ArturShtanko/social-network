
import React from "react";

function Friend(props){
    return(
        <div className="friend-slot">
            <img className="friend-slot-ava" src={props.avatar}></img>
            <span className="friend-slot-name">{props.name}</span>
        </div>
    );
}

export default Friend;