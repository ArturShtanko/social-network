
import React from "react";
import {NavLink} from "react-router-dom"
import "./navbar.css"

import Friend from "./friend/friend";

function Navbar(props){
    return(
      <div className="navbar">
        <NavLink to="/profile">Profile</NavLink>
        <NavLink to="/messages">Messages</NavLink>
        <NavLink to="/users">Users</NavLink>
        <NavLink to="/feed">Feed</NavLink>
        <NavLink to="/friends">Friends</NavLink>

        <div className="friends-wrapper">
          {props.friendList.map((e) => <Friend name={e.name} avatar={e.avatar}></Friend>)}
        </div>
      </div>
    );
}

export default Navbar;