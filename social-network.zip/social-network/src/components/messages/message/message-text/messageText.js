
import React from "react";
import { NavLink } from "react-router-dom";

import "./messageText.css"

const MessageText = (props) =>{
    return(
        <div className="message-text">
            <NavLink className="text" to={"/dialogs/${props.id}"}>{props.text}</NavLink>
        </div>
    )
}

export default MessageText;