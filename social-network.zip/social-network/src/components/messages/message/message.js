
import React from "react";

import MessageItem from "./message-item/messageItem";
import MessageText from "./message-text/messageText";

import "./message.css"

function Message(props){
    return(
        <div className="message">
            <MessageItem id={props.id} name={props.name}></MessageItem>
            <MessageText id={props.id} text={props.text}></MessageText>
        </div>
    )
}

export default Message;