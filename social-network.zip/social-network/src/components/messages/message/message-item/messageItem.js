
import React from "react";
import { NavLink } from "react-router-dom";

import "./messageItem.css"

const MessageItem = (props) =>{
    return(
        <div className="message-item">
            <NavLink className="name" to={"/dialogs/${props.id}"}>{props.name}</NavLink>
        </div>
    )
}

export default MessageItem;