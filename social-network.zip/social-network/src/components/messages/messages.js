
import React from "react";
import "./messages.css";

import MessageItem from "./message/message-item/messageItem";
import MessageText from "./message/message-text/messageText";

function Messages(props){
    return(
        <div className="messages-wrapper">
            <div className="dialog">
                {props.dialogNames.map((e) => <MessageItem id={e.id} name={e.name}></MessageItem>)}
            </div>
            <div className="messages">
                {props.dialogItems.map((e) => <MessageText id={e.id} text={e.message}></MessageText>)}

                <div className="input-field">
                    <textarea placeholder="enter your message"></textarea>
                    <button>Send Message</button>
                </div>
            </div>
        </div>
    )
}

export default Messages;