
let state = {
    navbarPage: {
        friends: [
            {name: "John", avatar: "/avatars/1.png"},
            {name: "Ivan", avatar: "/avatars/2.png"},
            {name: "Kasey", avatar: "/avatars/3.png"}
        ]
    },

    profilePage: {
        messageArray: [
            {message: "Hello world", likes: 1}, 
            {message: "he", likes: 2}, 
            {message: "accca", likes: 4}, 
            {message: "hallo", likes: 7}, 
            {message: "yuy", likes: 11}, 
            {message: "oooooooooooooo", likes: 10101}
        ],
    },

    dialogPage: {
        dialogNames: [
            {name: "Ivan Ivanov", id: "1"}, 
            {name: "Donald Trump", id: "2"}, 
            {name: "Bill Gates", id: "3"}
        ],

        dialogItems: [
            {message: "Hello", id: "1"}, 
            {message: "Bye", id: "2"}, 
            {message: "Aaaaaaaaa", id: "3"}
        ],
    }
};

export let addPost = (postText) => {
    let newPost = {text: postText, id:4,likes: 0};
    state.profilePage.messageArray.push(newPost);
    console.log(state);
}

export default state;