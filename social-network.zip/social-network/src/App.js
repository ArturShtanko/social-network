import React from 'react'

import './App.css'

import Header from './components/header/Header';
import Navbar from './components/navbar/Navbar';
import Profile from './components/profile/Profile';
import Messages from './components/messages/messages';
import {BrowserRouter, Route} from 'react-router-dom';

function App(props) {
  return(
    <div className="wrapper">
      <BrowserRouter>
        <Header />
        <Navbar friendList={props.navbarData.friends}/>
        <div className='wrapper-content'>
          <Route exact path='/profile' render={() => <Profile messageData={props.profileData.messageArray}/>} addPost={props.addPost}/>
          <Route exact path='/messages' render={() => <Messages dialogNames={props.dialogData.dialogNames} dialogItems={props.dialogData.dialogItems}/>}/>
        </div>
      </BrowserRouter>
    </div>
  );
}

export default App;