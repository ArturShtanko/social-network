import React from 'react'
import './navbar.css'
function Navbar(){
	return(
		<div className='navbar'>
			<a>Profile</a>
			<a>Messages</a>
			<a>Users</a>
		</div>
	)

}

export default Navbar